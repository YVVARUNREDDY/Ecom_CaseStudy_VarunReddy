package com.ecom.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ecom.dao.IOrderDAO;
import com.ecom.dao.OrderDAOImpl;
import com.ecom.entity.Customer;
import com.ecom.entity.Product;
import com.ecom.exception.OrderNotFoundException;
import com.ecom.exception.ProductNotFoundException;

public class OrderServiceImpl implements IOrderService {

	private IOrderDAO iOrderDAO;

	public OrderServiceImpl() {
		super();
		this.iOrderDAO = new OrderDAOImpl();
	}

	@Override
	public boolean placeOrder(Customer customer, List<Map<Product, Integer>> productsAndQuantities,
			String shippingAddress) {
		boolean result = false;
		try {
			result = iOrderDAO.placeOrder(customer, productsAndQuantities, shippingAddress);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public List<Map<Product, Integer>> getOrdersByCustomer(int customerId) {
		List<Map<Product, Integer>> orderByCustomers = null;
		try {
			orderByCustomers = iOrderDAO.getOrdersByCustomer(customerId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ProductNotFoundException pnfe) {
			System.out.println(pnfe.getMessage());
		} catch (OrderNotFoundException onfe) {
			System.out.println(onfe.getMessage());
		}

		return orderByCustomers;
	}
}
