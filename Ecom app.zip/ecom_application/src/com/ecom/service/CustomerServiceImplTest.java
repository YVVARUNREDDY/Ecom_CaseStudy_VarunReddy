package com.ecom.service;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;

public class CustomerServiceImplTest {
	private ICustomerService customerService;

	@Before
	public void setUp() throws Exception {
		customerService= new CustomerServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		customerService=null;
	}

	@Test
	public final void testCreateCustomer() {
		boolean result = false;
		Customer customer = new Customer("ABC", "abc@gmail.com", "abc123");
		result = customerService.createCustomer(customer);
		assertTrue("Customer creation should be successful",result);
		}

	@Test
	public final void testDeleteCustomer() {
		boolean result = false;
		int customerId = 8;
		result = customerService.deleteCustomer(customerId);

		assertTrue("Customer deletion should be successful",result);
	}

	@Test
	public final void testViewCustomer() {
		Customer customer = null;
		int customerId = 3;
		customer = customerService.viewCustomer(customerId);

		assertTrue("Customer should not be null",customer != null);	}

	@Test
	public final void testViewCustomers() {
		List<Customer> customerList = null;
		customerList = customerService.viewCustomers();
		assertTrue("Customer list should not be null",customerList != null);	}

}
