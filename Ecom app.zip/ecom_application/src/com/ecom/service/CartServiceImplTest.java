package com.ecom.service;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public class CartServiceImplTest {
	private ICartService cartService;

	@Before
	public void setUp() throws Exception {
		cartService = new CartServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		cartService = null;
	}

	@Test
	public final void testAddToCart() {
		Customer customer = new Customer("John", "john@gmail.com", "john123");
		Product product = new Product("Smartphone", 800.00, "Latest smartphone model", 10);

		try {
			cartService.addToCart(customer, product, 2);

			assertTrue(true);

		} catch (RuntimeException ce) {
			fail("Unexpected CartException: " + ce.getMessage());
		}
	}

	@Test
	public final void testRemoveFromCart() {
		Customer customer = new Customer("John", "john@gmail.com", "john1234");
		Product product = new Product("Smartphone", 800.00, "Latest smartphone ", 10);

		try {
			cartService.addToCart(customer, product, 2);

			cartService.removeFromCart(customer, product);

			assertTrue(true);

		} catch (RuntimeException re) {
			fail("Unexpected RuntimeException: " + re.getMessage());
		}
	}

}
