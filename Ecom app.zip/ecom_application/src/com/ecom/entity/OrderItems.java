package com.ecom.entity;

import java.util.Objects;

public class OrderItems {
	private int orderItemId;
	private Order order;
	private Product product;
	private int quantity;

	public OrderItems() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderItems(Order order, Product product, int quantity) {
		super();
		this.order = order;
		this.product = product;
		this.quantity = quantity;
	}

	public int getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(int orderItemId) {
		this.orderItemId = orderItemId;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public int hashCode() {
		return Objects.hash(order, orderItemId, product, quantity);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderItems other = (OrderItems) obj;
		return Objects.equals(order, other.order) && orderItemId == other.orderItemId
				&& Objects.equals(product, other.product) && quantity == other.quantity;
	}

	@Override
	public String toString() {
		return "OrderItems [orderItemId=" + orderItemId + ", order=" + order + ", product=" + product + ", quantity="
				+ quantity + "]";
	}

}
