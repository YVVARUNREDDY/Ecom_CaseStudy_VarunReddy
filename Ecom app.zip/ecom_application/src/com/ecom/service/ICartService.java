package com.ecom.service;

import java.util.List;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;

public interface ICartService {
	boolean addToCart(Customer customer, Product product, int quantity);

	boolean removeFromCart(Customer customer, Product product);

	List<Product> getAllFromCart(Customer customer);
}
