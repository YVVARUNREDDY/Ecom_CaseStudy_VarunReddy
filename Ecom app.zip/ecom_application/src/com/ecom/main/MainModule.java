package com.ecom.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.ecom.entity.Customer;
import com.ecom.entity.Product;
import com.ecom.service.CartServiceImpl;
import com.ecom.service.CustomerServiceImpl;
import com.ecom.service.ICartService;
import com.ecom.service.ICustomerService;
import com.ecom.service.IOrderService;
import com.ecom.service.IProductService;
import com.ecom.service.OrderServiceImpl;
import com.ecom.service.ProductServiceImpl;

public class MainModule {
	private static ICustomerService customerService = new CustomerServiceImpl();
	private static IProductService productService = new ProductServiceImpl();
	private static ICartService cartService = new CartServiceImpl();
	private static IOrderService orderService = new OrderServiceImpl();

	public static void main(String[] args) {

		Customer customer = null;
		Product product = null;

		String name = null;
		String email = null;
		String password = null;
		int choice = -1;
		int innerChoice = -1;

		boolean success;

		int customerID = 0;

		Scanner scInput = new Scanner(System.in);
		while (choice != 0) {

			System.out.println("Following are the options:");
			System.out.println("1. Customer Management");
			System.out.println("2. Product Management");
			System.out.println("3. Cart Management");
			System.out.println("4. Order Management");
			System.out.println("0. Exit");
			System.out.print("Please enter your choice: ");

			choice = scInput.nextInt();
			scInput.nextLine();
			switch (choice) {
			case 1:
				innerChoice = -1;
				while (innerChoice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Insert Customer");
					System.out.println("2. Delete Customer");
					System.out.println("3. View customer by ID");
					System.out.println("4. View all customers");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.println("Enter customer details:");
						System.out.print("Name: ");
						name = scInput.nextLine();
						System.out.print("Email: ");
						email = scInput.nextLine();
						System.out.print("Password: ");
						password = scInput.nextLine();

						customer = new Customer(name, email, password);

						success = customerService.createCustomer(customer);

						if (success) {
							System.out.println("Customer created successfully!");
						} else {
							System.out.println("Failed to create customer.");
						}
						break;

					case 2:
						System.out.print("Enter customer ID to delete: ");
						customerID = scInput.nextInt();
						scInput.nextLine();

						success = customerService.deleteCustomer(customerID);

						if (success) {
							System.out.println("Customer deleted successfully!");
						} else {
							System.out.println("Failed to delete customer.");
						}
						break;
					case 3:
						System.out.print("Enter customer ID to view: ");
						customerID = scInput.nextInt();
						scInput.nextLine();

						customer = customerService.viewCustomer(customerID);

						if (customer != null) {
							System.out.println("Customer details: " + customer);
						} 
						break;

					case 4:
						List<Customer> customers = customerService.viewCustomers();
						if (customers != null && !customers.isEmpty()) {
							System.out.println("List of customers:");
							for (Customer c : customers) {
								System.out.println(c);
							}
						} else {
							System.out.println("No customers found.");
						}
						break;
					case 0:
						System.out.println("Exiting Customer Management.");
						innerChoice = 0;
						break;
					default:
						System.out.println("Incorrect option");
						break;
					}
				}break;

			case 2:
				innerChoice = -1;
				while (innerChoice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Insert Product");
					System.out.println("2. Delete Product");
					System.out.println("3. View Product by ID");
					System.out.println("4. View all Products");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.println("Enter product details:");
						System.out.print("Name: ");
						String productName = scInput.nextLine();
						System.out.print("Price: ");
						double productPrice = scInput.nextDouble();
						scInput.nextLine();
						System.out.print("Description: ");
						String productDescription = scInput.nextLine();
						System.out.print("Stock Quantity: ");
						int stockQuantity = scInput.nextInt();

						product = new Product(productName, productPrice, productDescription, stockQuantity);

						boolean productInserted = productService.createProduct(product);

						if (productInserted) {
							System.out.println("Product inserted successfully!");
						} else {
							System.out.println("Failed to insert product.");
						}
						break;

					case 2:
						System.out.println("Enter the product ID to delete:");
						int productIdToDelete = scInput.nextInt();

						boolean productDeleted = productService.deleteProduct(productIdToDelete);

						if (productDeleted) {
							System.out.println("Product deleted successfully!");
						} else {
							System.out.println("Failed to delete product.");
						}
						break;

					case 3:
						System.out.println("Enter the product ID to view:");
						int productIdToView = scInput.nextInt();

						Product viewedProduct = productService.viewProduct(productIdToView);

						if (viewedProduct != null) {
							System.out.println("Product details: " + viewedProduct);
						} 
						break;

					case 4:
						List<Product> allProducts = productService.viewProducts();

						if (allProducts != null && !allProducts.isEmpty()) {
							System.out.println("List of all products:");
							for (Product p : allProducts) {
								System.out.println(p);
							}
						} else {
							System.out.println("No products available.");
						}
						break;

					case 0:
						System.out.println("Exiting Product Management.");
						innerChoice = 0;
						break;

					default:
						System.out.println("Incorrect option");
						break;

					}
				}break;

			case 3:
				innerChoice = -1;
				while (innerChoice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Insert the Product in Cart");
					System.out.println("2. Delete the Product in Cart");
					System.out.println("3. List the Product in Cart for a Customer");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.println("Enter details to add product to cart:");
						System.out.print("Enter Customer ID: ");
						int customerIdAdd = scInput.nextInt();
						scInput.nextLine();
						customer = customerService.viewCustomer(customerIdAdd);

						if (customer == null) {
							System.out.println("Customer not found. Cannot add product to cart.");
							break;
						}

						System.out.print("Enter Product ID: ");
						int productIdAdd = scInput.nextInt();
						scInput.nextLine();

						product = productService.viewProduct(productIdAdd);

						if (product == null) {
							System.out.println("Product not found. Cannot add product to cart.");
							break;
						}

						System.out.print("Enter Quantity: ");
						int quantityAdd = scInput.nextInt();

						boolean addedToCart = cartService.addToCart(customer, product, quantityAdd);

						if (addedToCart) {
							System.out.println("Product added to cart successfully!");
						} else {
							System.out.println("Failed to add product to cart.");
						}
						break;

					case 2:
						System.out.println("Enter details to remove product from cart:");
						System.out.print("Enter Customer ID: ");
						int customerIdRemove = scInput.nextInt();
						scInput.nextLine();

						Customer customerToRemove = customerService.viewCustomer(customerIdRemove);

						if (customerToRemove == null) {
							System.out.println("Customer not found. Cannot remove product from cart.");
							break;
						}

						System.out.print("Enter Product ID: ");
						int productIdRemove = scInput.nextInt();
						scInput.nextLine();

						Product productToRemove = productService.viewProduct(productIdRemove);

						if (productToRemove == null) {
							System.out.println("Product not found. Cannot remove product from cart.");
							break;
						}

						boolean removedFromCart = cartService.removeFromCart(customerToRemove, productToRemove);

						if (removedFromCart) {
							System.out.println("Product removed from cart successfully!");
						} else {
							System.out.println("Failed to remove product from cart.");
						}
						break;

					case 3:
						System.out.println("Enter Customer ID to view cart:");
						System.out.print("Enter Customer ID: ");
						int customerIdViewCart = scInput.nextInt();
						scInput.nextLine();

						Customer customerToViewCart = customerService.viewCustomer(customerIdViewCart);

						if (customerToViewCart == null) {
							System.out.println("Customer not found. Cannot view cart.");
							break;
						}

						List<Product> productsInCart = cartService.getAllFromCart(customerToViewCart);

						if (productsInCart != null && !productsInCart.isEmpty()) {
							System.out.println("Products in Cart:");
							for (Product cartProduct : productsInCart) {
								System.out.println(cartProduct.toString());
							}
						} else {
							System.out.println("No products in the cart for the customer.");
						}
						break;

					case 0:
						System.out.println("Exiting Cart Management.");
						innerChoice = 0;
						break;

					default:
						System.out.println("Incorrect option");
						break;
					}
				}break;
				
			case 4:
				innerChoice = -1;
				while (innerChoice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Place an Order");
					System.out.println("2. View Orders by Customer");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.println("Enter details to place an order:");
						System.out.print("Enter Customer ID: ");
						int customerIdPlaceOrder = scInput.nextInt();
						scInput.nextLine();

						Customer customerPlaceOrder = customerService.viewCustomer(customerIdPlaceOrder);

						if (customerPlaceOrder == null) {
							System.out.println("Customer not found. Cannot place an order.");
							break;
						}

						List<Map<Product, Integer>> productsAndQuantities = new ArrayList<>();

						int productChoice;
						do {
							System.out.println("Available Products:");
							List<Product> allProducts = productService.viewProducts();
							for (int i = 0; i < allProducts.size(); i++) {
								System.out.println((i + 1) + ". " + allProducts.get(i).getName());
							}

							System.out.print("Choose a product (0 to finish): ");
							productChoice = scInput.nextInt();
							scInput.nextLine();

							if (productChoice > 0 && productChoice <= allProducts.size()) {
								Product selectedProduct = allProducts.get(productChoice - 1);
								System.out.print("Enter quantity for " + selectedProduct.getName() + ": ");
								int quantity = scInput.nextInt();
								scInput.nextLine(); 

								Map<Product, Integer> productQuantityMap = new HashMap<>();
								productQuantityMap.put(selectedProduct, quantity);
								productsAndQuantities.add(productQuantityMap);
							} else if (productChoice != 0) {
								System.out.println("Invalid choice. Please try again.");
							}
						} while (productChoice != 0);

						System.out.print("Enter shipping address: ");
						String shippingAddress = scInput.nextLine();

						boolean orderPlaced = orderService.placeOrder(customerPlaceOrder, productsAndQuantities,
								shippingAddress);

						if (orderPlaced) {
							System.out.println("Order placed successfully!");
						} else {
							System.out.println("Failed to place the order.");
						}
						break;

					case 2:
						System.out.println("Enter Customer ID to view orders:");
						System.out.print("Enter Customer ID: ");
						int customerIdViewOrders = scInput.nextInt();
						scInput.nextLine(); 

						Customer customerToViewOrders = customerService.viewCustomer(customerIdViewOrders);

						if (customerToViewOrders == null) {
							System.out.println("Customer not found. Cannot view orders.");
							break;
						}

						List<Map<Product, Integer>> orders = orderService
								.getOrdersByCustomer(customerToViewOrders.getCustomerId());

						if (orders != null && !orders.isEmpty()) {
							System.out.println("Orders for Customer ID " + customerToViewOrders.getCustomerId() + ":");
							for (Map<Product, Integer> order : orders) {
								System.out.println("Order Details:");
								for (Map.Entry<Product, Integer> entry : order.entrySet()) {
									product = entry.getKey();
									int quantity = entry.getValue();
									System.out.println("Product: " + product.getName() + ", Quantity: " + quantity);
								}
							}
						} else {
							System.out.println("No orders for the customer.");
						}
						break;

					case 0:
						System.out.println("Exiting Order Management.");
						break;

					default:
						System.out.println("Incorrect option");
						break;
					}
				}
				break;

			}
		}
		scInput.close();
	}
}

