package com.ecom.service;

import java.sql.SQLException;
import java.util.List;

import com.ecom.dao.CustomerDAOImpl;
import com.ecom.dao.ICustomerDAO;
import com.ecom.entity.Customer;
import com.ecom.exception.CustomerNotFoundException;

public class CustomerServiceImpl implements ICustomerService {

	private ICustomerDAO iCustomerDAO;

	public CustomerServiceImpl() {
		super();
		iCustomerDAO = new CustomerDAOImpl();
	}

	@Override
	public boolean createCustomer(Customer customer) {
		boolean result = false;
		try {
			result = iCustomerDAO.createCustomer(customer);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;

	}

	@Override
	public boolean deleteCustomer(int customerId) {
		boolean result = false;
		try {
			result = iCustomerDAO.deleteCustomer(customerId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CustomerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return result;
	}

	@Override
	public Customer viewCustomer(int customerId) {
		Customer customer = null;

		try {
			customer = iCustomerDAO.viewCustomer(customerId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CustomerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return customer;
	}

	@Override
	public List<Customer> viewCustomers() {
		List<Customer> customerList = null;

		try {
			customerList = iCustomerDAO.viewCustomers();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CustomerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return customerList;
	}
}
